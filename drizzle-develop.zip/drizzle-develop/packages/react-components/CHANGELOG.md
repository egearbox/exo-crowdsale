# Change Log

All notable changes to this project will be documented in this file.
See [Conventional Commits](https://conventionalcommits.org) for commit guidelines.

## [1.5.3](https://github.com/trufflesuite/drizzle/compare/@drizzle/react-components@1.5.2...@drizzle/react-components@1.5.3) (2020-09-01)

**Note:** Version bump only for package @drizzle/react-components





## [1.5.2](https://github.com/trufflesuite/drizzle/compare/@drizzle/react-components@1.5.1...@drizzle/react-components@1.5.2) (2020-09-01)

**Note:** Version bump only for package @drizzle/react-components





## 1.5.1 (2019-10-29)


### Bug Fixes

* use correct propTypes for AccountData ([8ff9a66](https://github.com/trufflesuite/drizzle/commit/8ff9a66)), closes [#4](https://github.com/trufflesuite/drizzle/issues/4)
