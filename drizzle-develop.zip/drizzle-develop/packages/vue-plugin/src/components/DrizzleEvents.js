import Vue from 'vue'
export const DrizzleEvents = new Vue()
