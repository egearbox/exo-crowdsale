export const isDrizzleInitialized = state => state.initialized

export const getRegisteredContracts = state => state.registeredContracts

export const drizzleInstance = state => state.drizzleInstance
