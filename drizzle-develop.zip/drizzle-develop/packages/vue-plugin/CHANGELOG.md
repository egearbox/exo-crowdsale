# Change Log

All notable changes to this project will be documented in this file.
See [Conventional Commits](https://conventionalcommits.org) for commit guidelines.

## [0.1.3](https://github.com/trufflesuite/drizzle/compare/@drizzle/vue-plugin@0.1.2...@drizzle/vue-plugin@0.1.3) (2020-09-01)

**Note:** Version bump only for package @drizzle/vue-plugin





## [0.1.2](https://github.com/trufflesuite/drizzle/compare/@drizzle/vue-plugin@0.1.1...@drizzle/vue-plugin@0.1.2) (2020-09-01)

**Note:** Version bump only for package @drizzle/vue-plugin





## 0.1.1 (2019-10-29)

**Note:** Version bump only for package @drizzle/vue-plugin
