module.exports = {
  singleQuote: true,
  semi: false
}
