module.exports = {
  configureWebpack: {
    externals: /^(@drizzle|vue|vuex|lodash|rxjs)/
  }
}
