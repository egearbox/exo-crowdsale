const Grue = artifacts.require("Grue");

module.exports = function(deployer) {
  deployer.deploy(Grue);
};
