#! /usr/bin/env bash

npm  config set registry "https://registry.npmjs.org"
yarn config set registry "https://registry.yarnpkg.com"
